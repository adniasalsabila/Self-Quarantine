package org.d3if4133.side_project_adnia

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils.replace
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import org.d3if4133.side_project_adnia.database.TrackDatabase
import org.d3if4133.side_project_adnia.databinding.ActivityMainBinding
import org.d3if4133.side_project_adnia.databinding.FragmentHomeBinding
import org.d3if4133.side_project_adnia.fragment.HomeFragment
import org.d3if4133.side_project_adnia.viewmodel.TrackViewModel
import org.d3if4133.side_project_adnia.viewmodel.TrackViewModelFactory


class MainActivity : AppCompatActivity() {
    var layoutManager: RecyclerView.LayoutManager? = null
    var adapter: RecyclerView.Adapter<RecyclerAdapter.ViewHolder>? = null
    var adapter2: RecyclerView.Adapter<RecycleAdapterReq.ViewHolder>? = null

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        ReminderWorker.runAt()

        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
        layoutManager = LinearLayoutManager(this)
        recycler_view.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL ,false)
        recycler_view_req.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL ,false)

        adapter = RecyclerAdapter()
        recycler_view.adapter = adapter

        adapter2 = RecycleAdapterReq()
        recycler_view_req.adapter = adapter2
//
        binding.btStarted.setOnClickListener {
            startActivity(Intent(this,TampungFragment::class.java))
        }

        val navController = this.findNavController(R.id.mainFragment)
        NavigationUI.setupActionBarWithNavController(this, navController)
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = this.findNavController(R.id.mainFragment)
        return navController.navigateUp()
    }



}


